import React from "react";

function Certificate() {
  const [name, setName] = useSt;
  return <div>Certificate</div>;
}

export default Certificate;
