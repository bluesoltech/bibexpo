import React from "react";

function Footer() {
  return <div className="relative bottom-0 bg-blue-500 h-[25px]"></div>;
}

export default Footer;
